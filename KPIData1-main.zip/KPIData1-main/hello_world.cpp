#include <iostream>
int main()
{
std::cout<<"hellod world";
return 0;
}
